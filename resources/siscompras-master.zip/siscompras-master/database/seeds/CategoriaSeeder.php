<?php

use Illuminate\Database\Seeder;

class CategoriaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('categories')->insert(['nome' => 'EPI']);
        DB::table('categories')->insert(['nome' => 'Ferramentas Manuais']);
        DB::table('categories')->insert(['nome' => 'Ferramentas Eletricas']);
        DB::table('categories')->insert(['nome' => 'Cimento']);
        DB::table('categories')->insert(['nome' => 'Serralheria']);
        DB::table('categories')->insert(['nome' => 'Tinas']);
        DB::table('categories')->insert(['nome' => 'Pisos']);
        DB::table('categories')->insert(['nome' => 'Vidro']);
        DB::table('categories')->insert(['nome' => 'Munk']);
        DB::table('categories')->insert(['nome' => 'Hidraulico']);
        DB::table('categories')->insert(['nome' => 'Eletrica']);
        DB::table('categories')->insert(['nome' => 'Cabos eletricos']);

    }
}
